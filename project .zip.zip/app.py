import sqlite3
import json
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from orchestrator import run_local_agent

app = FastAPI(title="Field Assistant AI Review Portal")

DB_FILE = "site_audit.db"

def fetch_all_records(table_name: str):
    """Retrieves all serialized history payloads from the local SQLite database layer."""
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute(f"SELECT id, timestamp, payload FROM {table_name} ORDER BY id DESC")
        rows = cursor.fetchall()
        conn.close()
        
        records = []
        for row in rows:
            records.append({
                "id": row[0],
                "timestamp": row[1],
                "data": json.loads(row[2])
            })
        return records
    except Exception:
        return []

@app.get("/", response_class=HTMLResponse)
async def read_dashboard():
    """Generates a responsive dashboard interface to view change orders and logs."""
    change_orders = fetch_all_records("change_orders")
    delay_notices = fetch_all_records("delay_notices")
    daily_logs = fetch_all_records("daily_logs")
    
    # Simple, zero-dependency embedded HTML responsive template style layout
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Field Assistant AI - Home Office Portal</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f6f9; color: #333; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background-color: #0056b3; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
            .grid {{ display: grid; grid-template-columns: 1fr; gap: 20px; }}
            @media(min-width: 768px) {{ .grid {{ grid-template-columns: 1fr 1fr; }} }}
            .card {{ background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            h2 {{ color: #0056b3; border-bottom: 2px solid #eee; padding-bottom: 10px; }}
            .record {{ background: #fafafa; padding: 10px; border-left: 4px solid #0056b3; margin-bottom: 10px; font-size: 14px; border-radius: 0 4px 4px 0; }}
            .time {{ font-size: 12px; color: #777; font-weight: bold; }}
            pre {{ background: #eee; padding: 5px; border-radius: 3px; font-size: 12px; overflow-x: auto; }}
            .form-box {{ background: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
            input[type="text"], textarea {{ width: 100%; padding: 10px; margin: 5px 0 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }}
            button {{ background-color: #28a745; color: white; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; font-size: 16px; font-weight: bold; }}
            button:hover {{ background-color: #218838; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>FIELD ASSISTANT AI</h1>
                <p>Offline Synchronization Review Portal & Production Dashboard</p>
            </div>
            
            <div class="form-box">
                <h2>Simulate Field Text Note Submission</h2>
                <form action="/submit-transcript" method="post">
                    <label><b>Enter Raw Audio Transcript Text:</b></label>
                    <textarea name="transcript" rows="3" placeholder="Type field update notes here..." required></textarea>
                    <button type="submit">Process & Enforce Schema</button>
                </form>
            </div>

            <div class="grid">
                <div class="card">
                    <h2>📋 Change Orders History ({len(change_orders)})</h2>
                    {"".join([f'<div class="record"><span class="time">Archived: {r["timestamp"]}</span><pre>{json.dumps(r["data"], indent=2)}</pre></div>' for r in change_orders]) if change_orders else '<p>No field logs synchronized yet.</p>'}
                </div>
                
                <div class="card">
                    <h2>⚠️ Delay Notices History ({len(delay_notices)})</h2>
                    {"".join([f'<div class="record"><span class="time">Archived: {r["timestamp"]}</span><pre>{json.dumps(r["data"], indent=2)}</pre></div>' for r in delay_notices]) if delay_notices else '<p>No delay notice records documented yet.</p>'}
                </div>
            </div>
        </div>
    </body>
    </html>
    """
    return html_content

@app.post("/submit-transcript", response_class=HTMLResponse)
async def handle_transcript_submission(transcript: str = Form(...)):
    """Triggers the full processing pipeline dynamically when a submission hits the portal."""
    print(f"📥 Received active dashboard web payload entry request submission...")
    
    # Process text through your existing Step 3 / 4 / 5 orchestrator brain pipeline script
    run_local_agent(transcript)
    
    # Refresh dashboard view to display the newly compiled entry update instantly
    return """
    <html>
        <head><meta http-equiv="refresh" content="1;url=/" /></head>
        <body><p style="font-family:sans-serif; text-align:center; margin-top:50px;"><b>🤖 Processing payload... Syncing local audit database trail...</b></p></body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
