import json
import ollama
from schemas import IntentClassification, ChangeOrderOutput, DailyLogOutput, DelayNoticeOutput
from contract_rag import query_contract_context
from pdf_generator import generate_pdf_report
from database import log_to_audit_trail

def run_local_agent(raw_text: str):
    print("🤖 Processing text through Ollama Router...")

    # 1. Routing step
    router_prompt = (
        "You are a strict construction data router. Analyze the transcript text and classify its intent. "
        "Your output must be a single JSON object using EXACTLY these keys:\n"
        "{\n"
        '  "intent": "CHANGE_ORDER" or "DAILY_LOG" or "DELAY_NOTICE" or "MATERIAL_RECEIPT",\n'
        '  "confidence": 0.95\n'
        "}\n\n"
        f"Transcript text: \"{raw_text}\""
    )

    response = ollama.generate(model="gemma:2b", prompt=router_prompt, format="json", options={"temperature": 0.0})

    # IRONCLAD PYTON KEYWORD OVERRIDE: Bypasses small model routing errors instantly
    raw_resp_str = raw_text.upper()
    if any(keyword in raw_resp_str for keyword in ["DELAY", "BLOCKING", "OBSTRUCTION", "BOTTLENECK", "HOLDING UP"]):
        detected_intent = "DELAY_NOTICE"
    else:
        try:
            intent_data = json.loads(response['response'])
            classification = IntentClassification(**intent_data)
            detected_intent = classification.intent
        except Exception:
            detected_intent = "CHANGE_ORDER" if "CHANGE" in raw_resp_str else "DAILY_LOG"
    
    print(f"🎯 Detected Document Intent: {detected_intent}")

    # Fetch local RAG context from our contract vector database
    contract_context = query_contract_context(raw_text)

    # 2. Schema Selection & Parsing
    if detected_intent == "DELAY_NOTICE":
        schema_format = '{"impeding_trade": "text string", "description_of_obstruction": "text string", "legal_notice_language": "text string"}'
    elif detected_intent == "CHANGE_ORDER":
        schema_format = '{"project_name": "text string", "trade": "text string", "out_of_scope_description": "text string", "labor_hours": 0.0, "material_cost": 0.0, "total_claim": 0.0}'
    else:
        schema_format = '{"headcount_breakdown": ["string"], "tasks_completed": ["string"], "equipment_downtime": ["string"], "safety_notes": "text string"}'

    extraction_prompt = (
        f"You are an expert extraction engine. Read the field transcript text and extract the real details.\n"
        f"Do NOT use words like 'Name', 'Trade', or 'Detail'. Look at the user text and find the actual information.\n\n"
        f"Output ONLY a valid JSON object following this exact key template layout:\n{schema_format}\n\n"
        f"User text to extract from: \"{raw_text}\""
    )
    
    extraction_response = ollama.generate(model="gemma:2b", prompt=extraction_prompt, format="json", options={"temperature": 0.0})

    try:
        parsed_json = json.loads(extraction_response['response'])
        
        if detected_intent == "CHANGE_ORDER": 
            structured_output = ChangeOrderOutput(**parsed_json)
            target_table = "change_orders"
        elif detected_intent == "DELAY_NOTICE": 
            structured_output = DelayNoticeOutput(**parsed_json)
            target_table = "delay_notices"
        else: 
            structured_output = DailyLogOutput(**parsed_json)
            target_table = "daily_logs"
            
        print("\n✅ Successfully structured into validated data format:")
        print(json.dumps(structured_output.model_dump(), indent=2))
        
        # Commit data directly into the database archive file
        log_to_audit_trail(target_table, structured_output)
        
        # Automatically fire up the PDF compiler report engine
        generate_pdf_report(detected_intent, structured_output.model_dump(), "final_site_report.pdf")
        return structured_output
        
    except Exception as e:
        print(f"❌ Structural validation error: {e}")
        print("Raw AI Output was:", extraction_response['response'])

if __name__ == "__main__":
    sample_field_transcript = (
        "Hey look, we are on the Oakridge tower site. The drywall framing crew is completely "
        "blocking access to the mechanical room corridors, so my HVAC crew can't run the main "
        "ductwork trunk line. This is holding up our sequence for the entire week."
    )
    run_local_agent(sample_field_transcript)
