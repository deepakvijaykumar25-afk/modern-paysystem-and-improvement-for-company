import os
import argparse
from faster_whisper import WhisperModel

def transcribe_audio(audio_path: str, model_size: str = "base"):
    """
    Transcribes audio using faster-whisper quantized for local CPU execution
    with a construction-specific vocabulary bias.
    """
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    # 1. Initialize the model optimized for CPU with INT8 quantization
    print(f"Loading Whisper model '{model_size}' optimized for CPU (int8)...")
    model = WhisperModel(
        model_size, 
        device="cpu", 
        compute_type="int8"
    )

    # 2. Craft the initial trade prompt
    # This guides the model to correctly spell technical terminology in noisy environments.
    construction_prompt = (
        "This is a field audio recording from a construction job site. "
        "Keywords include: conduit, junction box, dry-wall, HVAC, rough-in, EMT, "
        "circuit breaker, load center, studs, blueprints, O&M manuals, framing, "
        "subpanel, voltage tester, wire strippers, MC cable, and structural layout."
    )

    print(f"Transcribing: {audio_path}...")
    
    # 3. Run transcription with the initial prompt injected
    segments, info = model.transcribe(
        audio_path, 
        beam_size=5,
        initial_prompt=construction_prompt
    )

    print(f"Detected language '{info.language}' with probability {info.language_probability:.2f}")
    print("\n--- Transcription Start ---")
    
    # The segments generator yields text pieces as they are decoded
    for segment in segments:
        print(f"[{segment.start:.2f}s -> {segment.end:.2f}s] {segment.text}")
        
    print("--- Transcription End ---")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Transcribe construction field audio using local int8 faster-whisper.")
    parser.add_argument("audio_file", type=str, help="Path to the audio file (wav, mp3, m4a, etc.)")
    parser.add_argument("--model", type=str, default="base", help="Whisper model size (tiny, base, small, medium, large-v3)")
    
    args = parser.parse_args()
    
    try:
        transcribe_audio(args.audio_file, model_size=args.model)
    except Exception as e:
        print(f"Error: {e}")
