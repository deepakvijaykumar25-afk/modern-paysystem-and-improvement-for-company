import sqlite3
import json
from datetime import datetime

DB_FILE = "site_audit.db"

def init_db():
    """Initializes the local SQLite database and creates structural audit tables if they do not exist."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # 1. Create tables for tracking historical records
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS daily_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        payload TEXT NOT NULL
    )
    """)
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS change_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        payload TEXT NOT NULL
    )
    """)
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS delay_notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        payload TEXT NOT NULL
    )
    """)
    
    conn.commit()
    conn.close()

def log_to_audit_trail(table_name: str, pydantic_model):
    """Serializes a validated Pydantic model to JSON text strings and logs it into SQLite with a local timestamp."""
    # Ensure database structure exists before writing entries
    init_db()
    
    # Target table whitelist validation to protect script queries
    valid_tables = ["daily_logs", "change_orders", "delay_notices"]
    if table_name not in valid_tables:
        raise ValueError(f"Invalid audit table target: {table_name}")
        
    # 2. Serialize the Pydantic data payload into a standard JSON string
    json_payload = json.dumps(pydantic_model.model_dump())
    current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 3. Open connection and execute query insertion safely
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    query = f"INSERT INTO {table_name} (timestamp, payload) VALUES (?, ?)"
    cursor.execute(query, (current_timestamp, json_payload))
    
    conn.commit()
    conn.close()
    print(f"🗄️ Entry successfully archived locally inside audit table: '{table_name}' at {current_timestamp}")

if __name__ == "__main__":
    init_db()
    print("Local SQLite audit trail database initialized successfully.")
