from pydantic import BaseModel, Field
from typing import List, Optional
from enum import Enum

class IntentEnum(str, Enum):
    CHANGE_ORDER = "CHANGE_ORDER"
    DAILY_LOG = "DAILY_LOG"
    DELAY_NOTICE = "DELAY_NOTICE"
    MATERIAL_RECEIPT = "MATERIAL_RECEIPT"

class IntentClassification(BaseModel):
    intent: IntentEnum = Field(description="The primary classification of the incoming field document or transcription text.")
    confidence: float = Field(description="Confidence score between 0.0 and 1.0.")

class ChangeOrderOutput(BaseModel):
    project_name: str = Field(description="Name of the construction project.")
    trade: str = Field(description="The impacted trade (e.g., Electrical, HVAC, Plumbing, Framing).")
    out_of_scope_description: str = Field(description="Detailed explanation of the out-of-scope work requested.")
    labor_hours: Optional[float] = Field(None, description="Estimated extra labor hours required.")
    material_cost: Optional[float] = Field(None, description="Estimated cost of materials needed.")
    total_claim: Optional[float] = Field(None, description="Total monetary claim amount if mentioned.")

class DailyLogOutput(BaseModel):
    headcount_breakdown: List[str] = Field(description="List of trades and the number of workers present on site.")
    tasks_completed: List[str] = Field(description="Bullet points of construction milestones or tasks finished today.")
    equipment_downtime: Optional[List[str]] = Field(None, description="Any machinery or tool downtime reported.")
    safety_notes: Optional[str] = Field(None, description="Any safety incidents, hazards, or site checks performed.")

class DelayNoticeOutput(BaseModel):
    impeding_trade: str = Field(description="The specific trade or entity causing the project bottleneck.")
    description_of_obstruction: str = Field(description="Clear details on what is physically or logistically stopping progress.")
    legal_notice_language: str = Field(description="Formal clause or statement indicating that this delays the project schedule timeline.")
