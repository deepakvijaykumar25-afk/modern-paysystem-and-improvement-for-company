import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

def generate_pdf_report(intent_type: str, data_payload: dict, output_filename: str = "final_site_report.pdf"):
    """
    Generates an official printable field report and invoice PDF using reportlab.
    Bypasses WeasyPrint system dependencies to guarantee execution.
    """
    # Enforce correct pdf extension layout matching rules
    if output_filename.endswith(".txt"):
        output_filename = output_filename.replace(".txt", ".pdf")
        
    print(f"📄 Compiling official layout into printable PDF for: {intent_type}...")
    
    # 1. Setup Document Layout
    doc = SimpleDocTemplate(
        output_filename,
        pagesize=letter,
        rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
    )
    story = []
    
    # 2. Setup Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontSize=24,
        leading=28,
        textColor=colors.HexColor("#0056b3")
    )
    section_heading = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontSize=14,
        leading=18,
        textColor=colors.HexColor("#333333"),
        spaceBefore=15,
        spaceAfter=10
    )
    body_style = styles['BodyText']
    
    # 3. Header Section
    story.append(Paragraph("FIELD ASSISTANT AI - OFFICIAL REPORT", title_style))
    story.append(Paragraph("<b>Category:</b> " + str(intent_type), body_style))
    story.append(Spacer(1, 15))
    
    # 4. Body Content (Out of Scope / Details Description)
    story.append(Paragraph("Description of Work / Obstruction", section_heading))
    desc = data_payload.get("out_of_scope_description") or data_payload.get("description_of_obstruction") or "General site activities logged."
    story.append(Paragraph(str(desc), body_style))
    story.append(Spacer(1, 15))
    
    # 5. Financial Breakdown Table Logic (Labor x Rate + Materials)
    story.append(Paragraph("Cost Breakdown & Financial Claims", section_heading))
    
    labor_hours = float(data_payload.get("labor_hours") or 0.0)
    rate = 65.00  # Default standard trade labor rate block factor mapping values
    labor_total = labor_hours * rate
    material_cost = float(data_payload.get("material_cost") or 0.0)
    
    # If the model extracted an explicit total claim use it, otherwise calculate it dynamically
    total_due = float(data_payload.get("total_claim") or (labor_total + material_cost))
    if total_due == 0.0 and (labor_total + material_cost) > 0.0:
        total_due = labor_total + material_cost

    table_data = [
        [Paragraph("<b>Item Description</b>", body_style), Paragraph("<b>Quantity / Cost</b>", body_style), Paragraph("<b>Total Due</b>", body_style)],
        [Paragraph(f"Labor Hours ({labor_hours} hrs @ ${rate:.2f}/hr)", body_style), f"${labor_total:.2f}", f"${labor_total:.2f}"],
        [Paragraph("Material Costs & Surcharges", body_style), f"${material_cost:.2f}", f"${material_cost:.2f}"],
        [Paragraph("<b>TOTAL CLAIM AMOUNT</b>", body_style), "", f"<b>${total_due:.2f}</b>"]
    ]
    
    financial_table = Table(table_data, colWidths=[280, 120, 120])
    financial_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#f8f9fa")),
        ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ('SPAN', (1, 3), (2, 3)), # Span across column for total cell layout structure formatting block mapping
        ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor("#e6f4ea")),
    ]))
    story.append(financial_table)
    story.append(Spacer(1, 40))
    
    # 6. Physical Signature Sign-Off Block for Site Supervisors
    story.append(Paragraph("Authorization & Field Sign-Off", section_heading))
    story.append(Spacer(1, 10))
    
    sig_data = [
        [Paragraph("<b>Prepared By:</b> Local Project Core Pipeline", body_style), Paragraph("<b>Authorized Supervisor Sign-Off:</b>", body_style)],
        ["", ""],  # Spacer row inside signature columns
        [Paragraph("Date: ________________________", body_style), Paragraph("Signature: ___________________________", body_style)]
    ]
    sig_table = Table(sig_data, colWidths=[260, 260])
    sig_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'BOTTOM'),
        ('BOTTOMPADDING', (0, 1), (-1, 1), 30), # Creates clean white space vertical pad height area for pen sign-off signature block lines
    ]))
    story.append(sig_table)
    
    # Build Document Output
    doc.build(story)
    print(f"🚀 Success! Stamped Printable PDF generated locally at: {os.path.abspath(output_filename)}")
    return output_filename

if __name__ == "__main__":
    test_data = {"out_of_scope_description": "Additional EMT conduit routing inside electrical vault room.", "labor_hours": 12, "material_cost": 450.0}
    generate_pdf_report("CHANGE_ORDER", test_data, "sample_invoice.pdf")
