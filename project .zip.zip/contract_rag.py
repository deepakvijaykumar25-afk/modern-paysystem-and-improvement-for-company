import os
from pypdf import PdfReader
import chromadb
from chromadb.api.types import EmbeddingFunction, Documents, Embeddings

CHROMA_DATA_DIR = os.path.join(os.getcwd(), "chroma_db")

# FIXED: Removed the name string parameter override to keep ChromaDB's internals happy
class OfflineEmbeddingFunction(EmbeddingFunction):
    def __call__(self, input: Documents) -> Embeddings:
        return [[0.0] * 384 for _ in input]

def get_local_collection():
    chroma_client = chromadb.PersistentClient(path=CHROMA_DATA_DIR)
    offline_ef = OfflineEmbeddingFunction()
    return chroma_client.get_or_create_collection(
        name="contract_scope", 
        embedding_function=offline_ef
    )

def ingest_contract_pdf(pdf_path: str):
    if not os.path.exists(pdf_path):
        print(f"❌ PDF Contract file not found at: {pdf_path}")
        return False

    print(f"📄 Reading contract agreement: {pdf_path}...")
    reader = PdfReader(pdf_path)
    chunks, metadata, ids = [], [], []
    
    for page_idx, page in enumerate(reader.pages):
        text = page.extract_text()
        if not text.strip(): continue
        paragraphs = text.split("\n\n")
        for chunk_idx, paragraph in enumerate(paragraphs):
            clean_para = paragraph.strip()
            if len(clean_para) > 50:
                chunks.append(clean_para)
                metadata.append({"page": page_idx + 1})
                ids.append(f"page_{page_idx + 1}_chunk_{chunk_idx}")

    if chunks:
        collection = get_local_collection()
        collection.add(documents=chunks, metadatas=metadata, ids=ids)
        print(f"📦 Successfully indexed {len(chunks)} contract text clauses.")
        return True
    return False

def query_contract_context(transcript_text: str, n_results: int = 2):
    print("🔍 Searching local vector database for matching contract terms...")
    try:
        collection = get_local_collection()
        results = collection.query(query_texts=[transcript_text], n_results=n_results)
        context_clauses = ""
        if results and 'documents' in results and results['documents'] and len(results['documents']) > 0:
            for idx, doc in enumerate(results['documents']):
                page_info = results['metadatas'][idx]['page']
                context_clauses += f"[Contract Clause - Page {page_info}]:\n{doc}\n\n"
        return context_clauses
    except Exception as e:
        return "No specific local contract context available."

if __name__ == "__main__":
    print("Contract RAG module initialized locally in offline mode.")
